Hallway with Guard READ ME - 
Each folder contains a prototype that aligns with its respective title, one named "ART" and one named "GP" as per the instructions.
The ART prototype contains only art assets in a well-lit environment that the player may move around, and the GP test features multiple main features intended to be implemented
in the final version, however many of the visual assets are broken or underbaked (especially such as the walls and the guard)

Controls for the gameplay test - 
WASD for movement
F to activate the flashlight
Left click to swing the hatchet 

Gameplay test notes - 
The flashlight is not automatically active upon entering the game, it must be activated with F to observe its effects.
The hatchet can be used to stun the guard, but the implementation is rudimentary and somewhat inconsistent at this point in time.
The guard is represented by a cylindrical object, as the model was not finished by the time the build was created.

Controls for Art Test - 
WASD for movement

Art Test Notes - 
Pretty self-explanatory here, no elements are interactable but rather are placed so that you may move around and observe them.

Github Repository Link - 
https://github.com/hi5aj/HorrorWithGuardWithIgnore.git 